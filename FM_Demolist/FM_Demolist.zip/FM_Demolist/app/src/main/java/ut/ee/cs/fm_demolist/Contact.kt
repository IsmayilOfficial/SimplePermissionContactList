package ut.ee.cs.fm_demolist

import android.graphics.Bitmap

data class Contact (val name:String,val phoneNumber:String,val email:String,val photo:Bitmap?)

